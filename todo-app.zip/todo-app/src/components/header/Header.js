import React from 'react';
import './Header.css'
import ReactIcon from '../svg/ReactIcon';

const Header = () => {
    return (
        <header className='Header'>
            <div className="react-icon-box">
                <ReactIcon />
            </div>
            <h1 className="header-primary">
                REACT TODO
            </h1>
        </header>
    )
};

export default Header;
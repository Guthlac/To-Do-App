import React from 'react';
import './InputBox.css';
import PlusIcon from '../svg/PlusIcon';

const inputBox = (props) => {
    const checkKey = (e) => {
        if (e.keyCode === 13) {
            props.submit()
        }
    }

    return (
        <div className="container">
            <input type="text" placeholder="Input a task" className="InputBox" onKeyDown={checkKey} />

            <div className="PlusIcon" onClick={props.submit}>
                <PlusIcon />
            </div>
        </div>
    )
};

export default inputBox;
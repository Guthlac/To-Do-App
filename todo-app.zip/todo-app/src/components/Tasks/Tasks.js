import React from 'react';
import './Tasks.css'
import TickIcon from '../svg/TickIcon';

const tasks = (props) => {
    let classes = ['Tasks'];
    
    const taskArr = props.tasks.map((task) => {
        const uniqid = require('uniqid');
        const id = uniqid('ID:');

        return (
            <div className="task" id={id} key={id}>
                <div className="icon">
                    <div onClick={props.complete.bind(this, id)}>
                        <TickIcon />
                    </div>
                </div>
                <div className="task-text">
                    {task}
                </div>
            </div>
        );
    });

    if (props.scrolling) {
        classes = ['Tasks', 'padding-left-small'];
    }

    return (
        <div className={classes.join(" ")}>
            {taskArr}
        </div>
    );
};

export default tasks;
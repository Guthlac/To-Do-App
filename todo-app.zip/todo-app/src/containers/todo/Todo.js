import React, { Component } from 'react';
import './Todo.css'
import Header from '../../components/header/Header';
import Tasks from '../../components/Tasks/Tasks';
import InputBox from '../../components/inputBox/InputBox';

class Todo extends Component {
  state = {
    tasks: [],
    isScrolling: false,
  }

  submitHandler = () => {
    // Store InputBox in a variable
    const inputBox = document.querySelector(".InputBox");

    // Check if it has a value
    if (inputBox.value) {
      const newState = this.state;

      // Add value to new state
      newState.tasks.push(inputBox.value);

      // Update the state
      this.setState({
        tasks: newState.tasks
      });

      // Reset the value
      inputBox.value = '';
    }

    // Ensure it stays focused
    inputBox.focus();
  }

  checkIfScrolling = () => {
    const div = document.querySelector('.Tasks');
    let newScrolling;

    // Check if a scrollbar exists
    if (div.scrollHeight > div.clientHeight) {
      newScrolling = true;
    } else {
      newScrolling = false;
    }

    // Only update state if a change is needed to prevent infinite loop
    if (this.state.isScrolling !== newScrolling) {
      this.setState({
        isScrolling: newScrolling
      });
    }
  }


  completeTaskHandler = (id) => {
    // find the task with the given id
    const task = document.getElementById(id).textContent;

    // create new tasks array
    const newTasks = this.state.tasks.filter(e => e !== task);

    // update the state
    this.setState({
      tasks: newTasks
    })
  }

  componentDidUpdate() {
    this.checkIfScrolling();
  }

  render() {

    return (
      <div className="Todo">
        <Header />
        <Tasks
          scrolling={this.state.isScrolling}
          tasks={this.state.tasks}
          complete={this.completeTaskHandler}
          edit={this.editTaskHandler}
        />
        <InputBox submit={this.submitHandler} />
      </div>
    );
  }
}

export default Todo;